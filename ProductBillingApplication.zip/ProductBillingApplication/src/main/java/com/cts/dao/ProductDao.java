package com.cts.dao;

import com.cts.bean.Product;

public interface ProductDao {

	Product getProductDetails(int product_code);
}
