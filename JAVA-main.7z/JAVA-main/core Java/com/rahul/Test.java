package com.rahul;

public class Test
{
    public static void main(String[] args)
    {
//        Account account1 = new Account();
//        account1.setCustomer_name("Rahul Sai");
//        account1.setAccount_Number("8978023937");
//        account1.deposit_fund(500000);
//        account1.setEmail("rahulsai@gmail.com");
//        account1.setPhone_number("+91-9490100214");
//        System.out.println(account1.toString());
//
//        account1.deposit_fund(2_50_000.52);
//        account1.withdraw(1_00_000);
//        System.out.println(account1.getBalance());

//        Account account2 = new Account("rahul","rahul@gmail.com","+91-855023697");
//        System.out.println(account2.toString());

        VipCustomer rahul = new VipCustomer();
        
        System.out.println(rahul.toString());


    }
}


