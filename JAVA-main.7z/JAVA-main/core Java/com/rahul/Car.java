
/**
 * Car
 */
package com.rahul;
public class Car {

    int distance;
    String model = new String();
    public static void main(String[] args) 
    {
        System.out.println("class car");
    }
}