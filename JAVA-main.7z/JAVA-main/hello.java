public class hello {

    public static void main(String[] args){
        int [][] a , b[];
        a = new int[5][5];
        b = new int[2][2][2];
        System.out.println(a);
        System.out.println(b[0]);
        System.out.println(new demo());

    }

}
class demo
{

}
